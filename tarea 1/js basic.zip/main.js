console.log("iniciando Con JS");
var myName = "Vicky";
console.log(myName);
var age = 19;
console.log(age);
var ignasiAge = 32;
console.log(ignasiAge);
var ageDiff = age-ignasiAge;
console.log(ageDiff);
var legalAge = 21
if(age < legalAge){
    console.log("No eres mayor de 21")
} 
else if(age == legalAge){
    console.log("Tienes 21")
}
else{
    console.log("Eres mayor de 21")
}
if(age < ignasiAge){
    console.log("No eres mayor que Ignasi")
} 
else if(age == ignasiAge){
    console.log("Tienen la misma edad")
}
else{
    console.log("Eres mayor que Ignasi")
}