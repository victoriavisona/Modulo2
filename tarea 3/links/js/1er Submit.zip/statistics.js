let statistics = {
    democrats:[],
    republicans:[],
    independents:[],
    avg_votes_democrats:0,

}

let members = data.results[0].members;

for(let i=0; i<members.length; i++){

    if(members[i].party == "R")(statistics.republicans.push(members[i]));
    if(members[i].party == "D")(statistics.democrats.push(members[i]));
    if(members[i].party == "ID")(statistics.independents.push(members[i]));


}

function averagePartyVotes(array){
    let avg = 0;
    let sum = 0;

    for( let i=0; i < array.length; i++){

        sum += array[i].votes_with_party_pct;
        
    }
    avg = sum / array.length;

    return avg;
    
}
