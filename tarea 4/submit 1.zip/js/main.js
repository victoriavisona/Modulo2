const app = new Vue({
    el: "#app",
    data:{
        members: [],
    },
    methods:{
        getData: async function(api){
            let api = 'https://api.propublica.org/congress/v1/113/senate/members.json'
            let init = {
                method: 'GET',
                headers: {
                'X-API-Key':'z0o01G5xcikLE22yzEPgNVBt0CJR3kQYyOGVkWTc'
                }
            }
            fetch(api, init)
            .then(function(response){
                if(response.ok){
                    return response.json()
                }else{
                    throw new Error(response.status)
                }
            })
            .then(function(data){
                console.log(data)
                app.members = data.results[0].members
            })
            .catch(function(error){
                alert(error)
            })
        }

    }
})