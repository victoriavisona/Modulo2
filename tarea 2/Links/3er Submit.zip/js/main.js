const table = document.getElementById("senate-data")
var members = data.results[0].members
var tbody= document.createElement("tbody")
for(var i=0; i<members.length; i++){
    var tr= document.createElement("tr");
    var td1= document.createElement("td");
    var link= document.createElement("a");
    link.innerText=members[i].first_name + " " + members[i].middle_name + " " + members[i].last_name;
    link.href = members[i].url;
    td1.appendChild(link);
    tr.appendChild(td1);
    var td2= document.createElement("td");
    td2.innerText = members[i].party;
    tr.appendChild(td2);
    var td3= document.createElement("td");
    td3.innerText = members[i].state;
    tr.appendChild(td3);
    var td4= document.createElement("td");
    td4.innerText = members[i].seniority;
    tr.appendChild(td4);
    var td5= document.createElement("td");
    td5.innerText = members[i].votes_with_party_pct;
    tr.appendChild(td5);
    tbody.appendChild(tr);
}
table.appendChild(tbody);
